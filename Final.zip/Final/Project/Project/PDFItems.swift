//
//  PDFItems.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-14.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class PDFItems{
    
    static var pdf : [String] = ["pdf.png" ,"pdf.png", "pdf.png", "pdf.png" ]
    static var pdfName : [String] = ["PDF 1" ,"PDF 2", "PDF 3", "PDF 4" ]
    
}


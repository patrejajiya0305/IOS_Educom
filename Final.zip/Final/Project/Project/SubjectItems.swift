//
//  SubjectItems.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-13.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class SubjectItems{
    
    static var subject : [String] = ["cloud.png" ,"mobileapp.png", "datastructure.png", "networking.png" ]
    static var subjectName : [String] = ["Cloud Computing" ,"Mobile Applications", "Data Structure", "Networking" ]
    
}

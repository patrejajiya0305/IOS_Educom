//
//  PresentationTVCell.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-14.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import UIKit

class PresentationTVCell: UITableViewCell {
    
    
    
    @IBOutlet var imgPresentation: UIImageView!
    
    @IBOutlet var lblPresentation: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

//
//  TableItems.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-10.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation
class TableItems {
    static var Titles : [String] = ["Audio" ,"Video", "Presentation", "PDF" ,"Share" ,"Web View" , "Call/SMS/Email"]
    static var Subtitles : [String] = ["Listen Aloud" ,"Watch It Clear", "Present Better", "Read Carefully" ,"Share" ,"Explore" ,"Feedback Is Appreciated"]
    static var images : [String] = ["audio.png" , "video.png", "presentation.png", "pdf.png", "share.png","web.png","feedback.png"]
}

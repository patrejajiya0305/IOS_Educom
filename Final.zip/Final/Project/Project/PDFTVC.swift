//
//  PDFTVC.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-14.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import UIKit

class PDFTVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = 100

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return PDFItems.pdfName.count
        
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PDFCell", for: indexPath) as! PDFTVCell

        // Configure the cell...
        
        cell.imgPDF.image = UIImage(named: PDFItems.pdf[indexPath.row])
        cell.lblPDF.text = PDFItems.pdfName[indexPath.row]
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //    let infoAlert = UIAlertController(title: "Menu Action", message: TableItems.Titles[indexPath.row], preferredStyle: .alert)
        //    infoAlert.addAction(UIAlertAction(title: "So What !!!", style: .default, handler: nil))
        //    self.present(infoAlert, animated: true, completion: nil)
        
        switch indexPath.row {
        case 0:
            print("PDF1 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let pdf1VC = mainSB.instantiateViewController(withIdentifier: "PDF1Scene")
            navigationController?.pushViewController(pdf1VC, animated: true)
        case 1:
            print("PDF2 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let pdf2VC = mainSB.instantiateViewController(withIdentifier: "PDF1Scene")
            navigationController?.pushViewController(pdf2VC, animated: true)
        case 2:
            print("PDF3 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let pdf3VC = mainSB.instantiateViewController(withIdentifier: "PDF1Scene")
            navigationController?.pushViewController(pdf3VC, animated: true)
        case 3:
            print("PDF4 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let pdf4VC = mainSB.instantiateViewController(withIdentifier: "PDF1Scene")
            navigationController?.pushViewController(pdf4VC, animated: true)
        /*case 4:
            print("Share performed")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let shareVC = mainSB.instantiateViewController(withIdentifier: "ShareScene")
            navigationController?.pushViewController(shareVC, animated: true)
        case 5:
            print("Web performed")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let webVC = mainSB.instantiateViewController(withIdentifier: "WebScene")
            navigationController?.pushViewController(webVC, animated: true)
            
        case 6:
            print("Call, SMS, Email")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let contactdetailVC = mainSB.instantiateViewController(withIdentifier: "ContactDetailScene")
            navigationController?.pushViewController(contactdetailVC, animated: true)*/
            
        default:
            print("No Action")
        }
    }
    
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  SubjectCell.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-13.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import UIKit

class SubjectCell: UICollectionViewCell {
    
    @IBOutlet var imgSubject: UIImageView!
    
    @IBOutlet var lblSubject: UILabel!
}

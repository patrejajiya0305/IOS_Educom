//
//  HomeTVCell.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-10.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import UIKit

class HomeTVCell: UITableViewCell {
    
   
    
    @IBOutlet var imgHome: UIImageView!
    
    
    @IBOutlet var lblTitle: UILabel!
    
    @IBOutlet var lblSubtitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

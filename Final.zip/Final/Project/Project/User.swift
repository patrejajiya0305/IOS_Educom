//
//  User.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-09.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class User{
    var name: String!
   
    var email: String!
    var password: String!
    
    private static var userList = [String: User]()
    
    init(){
        self.name = ""
        
        self.email = ""
        self.password = ""
        
    }
    
    init(_ name: String,  _ email: String, _ password: String) {
        self.name = name
        
        self.email = email
        self.password = password
       
    }
    
    static func addUser(newUser: User) -> Bool {
        if self.userList[newUser.email] == nil{
            self.userList[newUser.email] = newUser
            return true
        }
        
        return false
    }
    
    static func getAllUsers() -> [String: User]{
        return userList
    }
    
    static func searchUser(userEmail: String) -> User {
        if self.userList[userEmail] != nil{
            return self.userList[userEmail]!
        }
        
        return User()
    }
    
    static func deleteUser(userEmail: String) -> Bool{
        if self.userList[userEmail] != nil{
            self.userList[userEmail] = nil
            return true
        }
        
        return false
    }
}










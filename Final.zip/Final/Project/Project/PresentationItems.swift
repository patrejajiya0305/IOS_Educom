//
//  PresentationItems.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-14.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import Foundation

class PresentationItems{
    
    static var presentation : [String] = ["presentation.png" ,"presentation.png", "presentation.png", "presentation.png" ]
    static var presentationName : [String] = ["Presentation 1" ,"Presentation 2", "Presentation 3", "Presentation 4" ]
    
}

//
//  PDFTVCell.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-14.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import UIKit

class PDFTVCell: UITableViewCell {
    
    
    @IBOutlet var imgPDF: UIImageView!
    
    @IBOutlet var lblPDF: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

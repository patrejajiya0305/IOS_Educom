//
//  PresentationTVC.swift
//  Project
//
//  Created by Jiya Patreja on 2018-08-14.
//  Copyright © 2018 Jiya Patreja. All rights reserved.
//

import UIKit

class PresentationTVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = 100

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return PresentationItems.presentationName.count
    }

    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PresentationCell", for: indexPath) as! PresentationTVCell

        // Configure the cell...
        
        
        cell.imgPresentation.image = UIImage(named: PresentationItems.presentation[indexPath.row])
        cell.lblPresentation.text = PresentationItems.presentationName[indexPath.row]
        

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //    let infoAlert = UIAlertController(title: "Menu Action", message: TableItems.Titles[indexPath.row], preferredStyle: .alert)
        //    infoAlert.addAction(UIAlertAction(title: "So What !!!", style: .default, handler: nil))
        //    self.present(infoAlert, animated: true, completion: nil)
        
        switch indexPath.row {
        case 0:
            print("Presentation1 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let presentation1VC = mainSB.instantiateViewController(withIdentifier: "Presentation1Scene")
            navigationController?.pushViewController(presentation1VC, animated: true)
        case 1:
            print("Presentation2 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let presentation2VC = mainSB.instantiateViewController(withIdentifier: "Presentation1Scene")
            navigationController?.pushViewController(presentation2VC, animated: true)
        case 2:
            print("Presentation3 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let presentation3VC = mainSB.instantiateViewController(withIdentifier: "Presentation1Scene")
            navigationController?.pushViewController(presentation3VC, animated: true)
        case 3:
            print("Presentation4 opened")
            let mainSB = UIStoryboard(name: "Main" , bundle : nil)
            let presentation4VC = mainSB.instantiateViewController(withIdentifier: "Presentation1Scene")
            navigationController?.pushViewController(presentation4VC, animated: true)
            /*case 4:
             print("Share performed")
             let mainSB = UIStoryboard(name: "Main" , bundle : nil)
             let shareVC = mainSB.instantiateViewController(withIdentifier: "ShareScene")
             navigationController?.pushViewController(shareVC, animated: true)
             case 5:
             print("Web performed")
             let mainSB = UIStoryboard(name: "Main" , bundle : nil)
             let webVC = mainSB.instantiateViewController(withIdentifier: "WebScene")
             navigationController?.pushViewController(webVC, animated: true)
             
             case 6:
             print("Call, SMS, Email")
             let mainSB = UIStoryboard(name: "Main" , bundle : nil)
             let contactdetailVC = mainSB.instantiateViewController(withIdentifier: "ContactDetailScene")
             navigationController?.pushViewController(contactdetailVC, animated: true)*/
            
        default:
            print("No Action")
        }
    }
    
    
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
